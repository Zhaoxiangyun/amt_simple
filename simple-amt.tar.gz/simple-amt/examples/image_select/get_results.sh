python get_results.py \
  --hit_ids_file=examples/image_select/hit_ids.txt \
  > examples/image_select/results.txt
