python show_hit_progress.py --hit_ids_file=examples/image_sentence/hit_ids.txt
