
python launch_hits.py \
      --html_template=image_select.html \
      --hit_properties_file=hit_properties/image_select.json \
      --input_json_file=examples/image_select/example_input.txt \
      --hit_ids_file=examples/image_select/hit_ids.txt
